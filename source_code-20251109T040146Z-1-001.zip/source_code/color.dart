import 'dart:ui';

import 'package:flutter/material.dart';

Color primaryColor = Colors.blue;
Color secondaryColor = Colors.blueGrey;
